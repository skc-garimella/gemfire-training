Pivotal(TM) GemFire(R) HTTP Session Management Module 8.2.0 for Tomcat

This module provides fast, scalable, and reliable HTTP session replication for Apache Tomcat.

Access all Pivotal GemFire Documentation at:
http://gemfire.docs.pivotal.io

Pivotal Support Services can be accessed from the Pivotal or VMware website.
Access varies by license type, support offering (contract or per-incident) and 
product. Please see the Pivotal page at http://www.pivotal.io/support or to 
file a VMware Support Request, please see the VMware page at 
https://www.vmware.com/support/policies/howto.html for information on "How to 
File a Support Request."

